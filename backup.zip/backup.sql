/*
SQLyog Job Agent v12.09 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 10.2.3-MariaDB-log : Database - lmi_operations
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`lmi_operations` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `lmi_operations`;

/*Table structure for table `accounts` */

DROP TABLE IF EXISTS `accounts`;

CREATE TABLE `accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `branch_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `account_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_admin` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accounts_username_unique` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `accounts` */

/*Table structure for table `branches` */

DROP TABLE IF EXISTS `branches`;

CREATE TABLE `branches` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `operation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `area` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `branch_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `branches_name_unique` (`name`),
  UNIQUE KEY `branches_branch_code_unique` (`branch_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `branches` */

/*Table structure for table `capital_build_ups` */

DROP TABLE IF EXISTS `capital_build_ups`;

CREATE TABLE `capital_build_ups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `amort_id` int(10) unsigned DEFAULT NULL,
  `disbursement_id` int(10) unsigned DEFAULT NULL,
  `client_id` int(10) unsigned DEFAULT NULL,
  `amount` int(10) unsigned DEFAULT NULL,
  `transaction_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `capital_build_ups` */

/*Table structure for table `client_businesses` */

DROP TABLE IF EXISTS `client_businesses`;

CREATE TABLE `client_businesses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `main_business` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `secondary_business` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `main_business_years` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `number_of_paid_employees` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `business_place_characteristic` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `client_businesses` */

/*Table structure for table `client_incomes` */

DROP TABLE IF EXISTS `client_incomes`;

CREATE TABLE `client_incomes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `member_lastname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_middlename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_suffix` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_age` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_relationship` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_occupation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_occupation_years` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_monthly_income` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `client_incomes` */

/*Table structure for table `clients` */

DROP TABLE IF EXISTS `clients`;

CREATE TABLE `clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `middlename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `branch_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `suffix` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nickname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mother_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `spouse_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIN` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `birthday` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `home_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `home_year` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `business_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `business_year` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telephone_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `civil_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sex` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `education` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `house_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clients_client_code_unique` (`client_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `clients` */

/*Table structure for table `cluster_members` */

DROP TABLE IF EXISTS `cluster_members`;

CREATE TABLE `cluster_members` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cluster_id` int(10) unsigned DEFAULT NULL,
  `client_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `cluster_members` */

/*Table structure for table `clusters` */

DROP TABLE IF EXISTS `clusters`;

CREATE TABLE `clusters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `branch_id` int(10) unsigned NOT NULL,
  `region` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pa_lastname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pa_firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clusters_code_unique` (`code`),
  KEY `clusters_branch_id_index` (`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `clusters` */

/*Table structure for table `collections` */

DROP TABLE IF EXISTS `collections`;

CREATE TABLE `collections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `amortization_id` int(10) unsigned NOT NULL,
  `principal` int(10) unsigned NOT NULL,
  `interest` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `collections` */

/*Table structure for table `credit_limit` */

DROP TABLE IF EXISTS `credit_limit`;

CREATE TABLE `credit_limit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned DEFAULT NULL,
  `co_maker_inside_cluster_id` int(10) unsigned DEFAULT NULL,
  `co_maker_outside_cluster_id` int(10) unsigned DEFAULT NULL,
  `business_net_disposable_income` bigint(20) DEFAULT NULL,
  `household_income` bigint(20) DEFAULT NULL,
  `household_expense` bigint(20) DEFAULT NULL,
  `financial_risk_assessment` bigint(20) DEFAULT NULL,
  `credit_limit` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `credit_limit` */

/*Table structure for table `disbursement` */

DROP TABLE IF EXISTS `disbursement`;

CREATE TABLE `disbursement` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cluster_id` int(10) unsigned DEFAULT NULL,
  `cv_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payee_id` int(10) unsigned DEFAULT NULL,
  `loan_amount` bigint(20) unsigned DEFAULT NULL,
  `check_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `release_date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_finished` tinyint(1) DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_collection_date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_collection_date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `maturity_date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `disbursement` */

/*Table structure for table `finished_disbursements` */

DROP TABLE IF EXISTS `finished_disbursements`;

CREATE TABLE `finished_disbursements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `disbursement_id` int(10) unsigned NOT NULL,
  `is_fully_paid` tinyint(1) NOT NULL,
  `finished` tinyint(1) NOT NULL,
  `comments` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `finished_disbursements` */

/*Table structure for table `loan_summaries` */

DROP TABLE IF EXISTS `loan_summaries`;

CREATE TABLE `loan_summaries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `disbursement_id` int(10) unsigned DEFAULT NULL,
  `client_id` int(10) unsigned DEFAULT NULL,
  `loan_amount` int(10) unsigned DEFAULT NULL,
  `loan_term` int(10) unsigned DEFAULT NULL,
  `cbu_new` int(10) unsigned DEFAULT NULL,
  `cbu_reloan` int(10) unsigned DEFAULT NULL,
  `processing_fee` int(10) unsigned DEFAULT NULL,
  `doc_stamp_tax` int(10) unsigned DEFAULT NULL,
  `mi_id` int(10) unsigned DEFAULT NULL,
  `mi_premium_cblic` double(8,2) unsigned DEFAULT NULL,
  `mi_premium_lmi` double(8,2) unsigned DEFAULT NULL,
  `cli_premium_lmi` double(8,2) unsigned DEFAULT NULL,
  `cli_premium_cblic` double(8,2) unsigned DEFAULT NULL,
  `total_pre_deductions` int(10) unsigned DEFAULT NULL,
  `total_loan_amount` int(10) unsigned DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_payed` tinyint(1) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `loan_summaries` */

/*Table structure for table `mi_dependent_information` */

DROP TABLE IF EXISTS `mi_dependent_information`;

CREATE TABLE `mi_dependent_information` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `term` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `member_payment` int(11) NOT NULL,
  `spouse_payment` int(11) NOT NULL,
  `child_payment` int(11) NOT NULL,
  `parent_payment` int(11) NOT NULL,
  `sibling_payment` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `mi_fee` int(11) NOT NULL,
  `head_count` int(11) NOT NULL,
  `total_mi_fee` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `mi_dependent_information` */

/*Table structure for table `migrations` */

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `migrations` */

/*Table structure for table `password_resets` */

DROP TABLE IF EXISTS `password_resets`;

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `password_resets` */

/*Table structure for table `past_dues` */

DROP TABLE IF EXISTS `past_dues`;

CREATE TABLE `past_dues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `amort_id` int(11) NOT NULL,
  `disbursement_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `principal` int(11) NOT NULL,
  `interest` int(11) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `week_to_be_paid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `to_be_collected_on` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `past_dues` */

/*Table structure for table `payment_informations` */

DROP TABLE IF EXISTS `payment_informations`;

CREATE TABLE `payment_informations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `payment_summary_id` int(10) unsigned DEFAULT NULL,
  `amort_id` int(10) unsigned DEFAULT NULL,
  `amount_paid` int(10) unsigned DEFAULT NULL,
  `principal_paid` int(10) unsigned DEFAULT NULL,
  `interest_paid` int(10) unsigned DEFAULT NULL,
  `this_week_balance` int(10) unsigned DEFAULT NULL,
  `week_interest_balance` int(10) unsigned DEFAULT NULL,
  `week_principal_balance` int(10) unsigned DEFAULT NULL,
  `payment_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `payment_informations` */

/*Table structure for table `payment_summaries` */

DROP TABLE IF EXISTS `payment_summaries`;

CREATE TABLE `payment_summaries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `disbursement_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `collection_date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `this_week_due` int(10) unsigned DEFAULT NULL,
  `this_week_total_amount_due` int(10) unsigned DEFAULT NULL,
  `last_week_past_due` int(10) unsigned DEFAULT NULL,
  `amount_paid` int(10) unsigned DEFAULT NULL,
  `principal_not_collected` int(10) unsigned DEFAULT NULL,
  `interest_not_collected` int(10) unsigned DEFAULT NULL,
  `uploader_id` int(10) unsigned DEFAULT NULL,
  `isFullyPaid` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `payment_summaries` */

/*Table structure for table `products` */

DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `interest_rate` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `min` bigint(20) DEFAULT NULL,
  `max` bigint(20) DEFAULT NULL,
  `weekly_compounding_rate` decimal(20,6) DEFAULT NULL,
  `loan_term` bigint(20) DEFAULT NULL,
  `weeks_to_pay` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `products` */

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lastname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `firstname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `users` */

/*Table structure for table `weekly_amortization` */

DROP TABLE IF EXISTS `weekly_amortization`;

CREATE TABLE `weekly_amortization` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `disbursement_id` int(10) unsigned DEFAULT NULL,
  `client_id` int(10) unsigned DEFAULT NULL,
  `week` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `principal_this_week` int(10) unsigned DEFAULT NULL,
  `interest_this_week` int(10) unsigned DEFAULT NULL,
  `principal_with_interest` int(10) unsigned DEFAULT NULL,
  `principal_balance` int(10) unsigned DEFAULT NULL,
  `interest_balance` int(10) unsigned DEFAULT NULL,
  `collection_date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `weekly_amortization` */

/*Table structure for table `yearly_calendar` */

DROP TABLE IF EXISTS `yearly_calendar`;

CREATE TABLE `yearly_calendar` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `holiday` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `holiday_date` date DEFAULT NULL,
  `day` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `year` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_weekend` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `yearly_calendar` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
